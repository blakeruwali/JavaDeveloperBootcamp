//related to Sdemo10
class Sdemo9 
{
   static int i =10;
	
		static Sdemo5 a1 = new Sdemo5();
	
}
