/*
If we create the context of a class from a non-static function , when control
comes out of the function , the function gets deleted from the memory space,
but the context of the class will available enter main() execution.
*/
class  Sdemo7
{
	void function1()
	{
		Sdemo3.j = 115;
		Sdemo3 s=new Sdemo3();
		s.i=50;
		System.out.println("Inside function1()"+s.i);//50
				System.out.println("Inside function1()"+s.j);//115
	}
	public static void main(String[] args) 
	{
		Sdemo7 s1 = new Sdemo7();
		s1.function1();
		System.out.println(Sdemo3.j);//115
					Sdemo3 s=new Sdemo3();

		System.out.println("Inside function1()"+s.i);//0 0

		System.out.println("Inside function1()"+s.j);//115
	}
}
