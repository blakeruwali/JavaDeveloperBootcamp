class Sdemo8

{
void function1()
	{
		System.out.println("Inside function1()");
		Sdemo3.j = 115;
		System.out.println("Inside function1()");
		
		
	}
	public static void main(String[] args) 
	{
		Sdemo8 s1 = new Sdemo8();
		Sdemo3.j = 10;
		System.out.println(Sdemo3.j);
		
		s1.function1();
		System.out.println(Sdemo3.j);
		Sdemo3 d = new Sdemo3();
		d.j =5;
		System.out.println(d.j);
		System.out.println(Sdemo3.j);
		
		s1.function1();
		
		

		

	}
}
