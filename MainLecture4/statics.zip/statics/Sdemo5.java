/*
Static variable and functions are available to non-Static functions directly,
but non-variable and non-staticfunction can not use directly in to the static function.

*/
class Sdemo5 
{	int x;
	static int y;
	void functionA()
	{	int y=0;
		System.out.println("inside non static method functionA()");
		x =10;
		y=30;
	 System.out.println(x);//
	 System.out.println(y);//
		functionZ();
System.out.println(x);//
	 System.out.println(y);//
	}
 static void functionZ()
	{ //System.out.println(x); //non static variable cannot be referenced from a static context
	 System.out.println("inside non static method functionZ()");
	 System.out.println(y);//
		}
	public static void main(String[] args) 
	{Sdemo5 s = new Sdemo5();
	s.functionA();
	}

	
}
