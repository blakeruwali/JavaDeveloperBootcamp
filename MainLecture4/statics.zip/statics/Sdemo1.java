//use of Static keyword with out creating an Object

class Sdemo1 
{
	int i;
	static int j;
	public static  void main(String[] args) 
	{
		Sdemo1 s=new Sdemo1();
		System.out.println(s.i);
		System.out.println(j);
		j = 25;
		System.out.println(j);
		Sdemo1 s1 = new Sdemo1();
		s1.i =20;
		System.out.println(s1.i);
				System.out.println(s1.j);
		
		
	}
}
