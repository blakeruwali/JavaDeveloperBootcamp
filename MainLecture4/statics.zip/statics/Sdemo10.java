//related to Sdemo10
class Sdemo9 
{
   static int i =10;
	//prinstream out=new printStream();
		static Sdemo5 a1 = new Sdemo5();
	
}



class Sdemo10
{
	static Sdemo10 a ;
	int x;
static	int j;


	public static void main(String[] args) 
	{   //we can declare like this 
		 //Sdemo10 a = null;
		System.out.println(a);
		//but no possibility like this
      /*
	  static Sdemo10 a = null;
		System.out.println(a); //illegal start of expression
		*/
		/*
         static Sdemo10 a = new Sdemo10();
		System.out.println(a); //illegal start of expression
	       */
		   /*
		   static int y =10;
		   System.out.println(y);//illegal start of expression
		   */
		 a = new Sdemo10();
		 System.out.println(a);
		 a.x = 25;
		 System.out.println(a.x);
		 a.j = 35;
		  System.out.println(a.j);
		   System.out.println(Sdemo10.j);
		
		
		Sdemo9.i =10;
		Sdemo9.a1.functionA();
		System.out.println("Hello World!");
	}
}
