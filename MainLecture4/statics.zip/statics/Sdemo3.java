/*
All the static variables would be common to all the reference of different objects of the same class

Cannot declare Two variables like static int j and int j simultaneously bcz,
we cannot declare two variables with same within the same class.
*/
class Sdemo3 
{
	int i;
	static int j;
	public static void main(String[] args) 
	{
       Sdemo3 s =  null;
//     System.out.println(s.i);//NullPointerException
        System.out.println(s.j);//0
		   Sdemo3 s1 =  new Sdemo3();
		   System.out.println(s1);//
            s1.i =25;
			s1.j =35;
           System.out.println(j); //35
		   Sdemo3 s2 =  new Sdemo3();
  		   Sdemo3 s3 =  new Sdemo3();
            s2.i =10;
		System.out.println(s3.i);//10
	   System.out.println(s3.j); //35


			  
	}
}
