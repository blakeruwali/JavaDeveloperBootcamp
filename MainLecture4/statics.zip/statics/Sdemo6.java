// access to the static elements of Sdemo3.java
class Sdemo3 
{	int i;
	static int j;
}
class Sdemo6 
{
	static int x;
	public static void main(String[] args) 
	{		x = x + 1;
		Sdemo3.j = 5;
		System.out.println(Sdemo3.j);//5
		Sdemo3 s1 = new Sdemo3();
		System.out.println(s1.j);//5
		s1.i = 203;
		System.out.println(s1.i);//203
}
}
/*
What is class
what is object
what is localvarible
non-static varibles
what are the primtive dataTypes
what is method what is the use
static varibles
What is java Advantages of java
what is user defind datatype.


*/
